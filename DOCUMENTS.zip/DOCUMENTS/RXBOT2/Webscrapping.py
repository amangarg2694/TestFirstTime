from urllib.request import Request,urlopen as uReq
from requests.exceptions import RequestException
from contextlib import closing
from bs4 import BeautifulSoup as soup

my_urls = 'http://guihelp.sxc.com/R1905/CLMMANJW/!SSL!/WebHelp/1_Trans/WITrans.htm','http://guihelp.sxc.com/R1905/CLMPRCJW/!SSL!/WebHelp/1_Price/1_PriceSch/WIPrcSch.htm','http://guihelp.sxc.com/R1905/CLMPRCJW/!SSL!/WebHelp/1_Price/2_PriceTbl/WIPrcTbl.htm','http://guihelp.sxc.com/R1905/CLMELGJW/!SSL!/WebHelp/8_ClmMbrID/RCTCD016.htm','http://guihelp.sxc.com/R1905/CLMELGJW/!SSL!/WebHelp/6_ClmTrns/WIClaim.htm','http://guihelp.sxc.com/R1905/CLMPLNJW/!SSL!/WebHelp/Plan/RCPLN051.htm','http://guihelp.sxc.com/R1905/CLMELGJW/!SSL!/WebHelp/2_Member/WIMembr.htm','http://guihelp.sxc.com/R1905/CLMPRVJW/!SSL!/WebHelp/1_Pharm/WIPhar.htm','http://guihelp.sxc.com/R1905/CLMPRDJW/!SSL!/WebHelp/2_GPIMas/WIGPIMst.htm','http://guihelp.sxc.com/R1905/CLMPRVJW/!SSL!/WebHelp/2_PhNtwk/WIPhNt.htm','http://guihelp.sxc.com/R1905/CLMPRVJW/!SSL!/WebHelp/8_Prescriber/WIPrescr.htm','http://guihelp.sxc.com/R1905/CLMPRVJW/!SSL!/WebHelp/14_CrNtwk/WICrNtwk.htm','http://guihelp.sxc.com/R1905/CLMPLNJW/!SSL!/WebHelp/8_PriAuth/WIPM8.htm','http://guihelp.sxc.com/R1905/CLMELGJW/!SSL!/WebHelp/3_MbrbyCar/RCMBR014.htm','http://guihelp.sxc.com/R1905/CLMELGJW/!SSL!/WebHelp/3_MbrbyCar/RCPRX008.htm','http://guihelp.sxc.com/R1905/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/WIPE11.htm#','http://guihelp.sxc.com/R1905/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/10_PlanNDC/WIPE10.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGT008.htm','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGG001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGK001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPG6001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGP001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGJ009.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGX001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPG9001.htm#','http://guihelp.sxc.com/V8R4M02/CLMPLNJW/!SSL!/WebHelp/Plan/PlanEdits/11_PlanGPI/RCPGJ004.htm#'
web_content_list = []

for url in my_urls:
    
    uClient = uReq(url)
    print(url)
    page_html = uClient.read()
    urls = []
    pretext = " For more information please refer below link::"
    temtext =  pretext + url
    urls.append(temtext)
    page_soup = soup(page_html, "html.parser")
    question_content = page_soup.h1.string
    paragraph_content = page_soup.findAll("p", {"class":"BodyText"})
    #print(question_content)
    #print("\n")
    #print (paragraph_content)
    #print("\n")
    #print("Before writing into dict")
    
    page_paras = page_soup.findAll("p", {"class":"BodyText"})
    
    answer = []
        
    for page_para in page_paras:
            
            page_pexcludr = page_para.text.replace("\r","").strip()
            page_exclud_rn = page_pexcludr.replace("\n","")
            page_exclud_rnx = page_exclud_rn.replace("\xa0","")
            final_para = page_exclud_rnx.replace("//<![CDATA[TextPopupInit('HotSpot26462', 'POPUP26462');//]]> "," ")
            #print(final_para)
            
            answer.append(final_para)

    paragraph_append = answer + urls
    paragraph_contents = paragraph_append
    #print("\n")
    #print("paragraph_contents")
    #print(paragraph_contents)
    #print("\n")
    
    
    # To process property by property by looping
    # To store the information to a dictionary
    web_content_dict = {}
    web_content_dict["Question"] = question_content
    web_content_dict["Answer"] = paragraph_contents
    web_content_dict["URL"] = urls  
  
    
# To store the dictionary to into a list
    web_content_list.append(web_content_dict)

#print(web_content_list)
import pandas as pd
#print(web_content_list)
df = pd.DataFrame(web_content_list)

df.to_csv(r'C:\Users\Agarg131\Desktop\ML projects\ChatbotIntegrated\Database2.csv',index = False)