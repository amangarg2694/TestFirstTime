# -*- coding: utf-8 -*-
"""
Created on Sat Jun  1 16:58:30 2019

@author: atiwar12
"""
#Loading Libraries
import pandas as pd
import numpy as np

#Import Vectorizer and Similarity measure
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

#Read the data
df = pd.read_csv('C:/Users/Agarg131/Desktop/RXBOT2/Database3.csv',encoding = "cp1252")
#df.dropna(inplace=True)

#Train the Vectorizer
vectorizer = TfidfVectorizer()
vectorizer.fit(np.concatenate((df.Question,df.Answer)))

#Vectorize Questions
Question_vectors = vectorizer.transform(df.Question)


#Read user input
usrText = input()


#Chat with User
def get_response(usrText):
    #print("You can start chatting with RxBot now.")
    while True:
		
        if usrText.strip()!= 'Bye':
		
            #Locate the closest question
            usrText_vector = vectorizer.transform([usrText])
            
            #Compute Similarities
            similarities = cosine_similarity(usrText_vector, Question_vectors)
            
            #Find the closest question
            closest = np.argmax(similarities, axis=1)
            
            #Print the correct answer
           
            result = df.Answer.iloc[closest].values[0]
            
            reply = str(result)
            return(reply)
        if usrText.strip() == 'Bye':
            return('Bye')
            break

